/****************** SERVER CODE ****************/

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include<unistd.h>
#include<math.h>
#include<stdlib.h>
#include<sys/types.h>
#include<netdb.h>



void func(int newSocket);

int main(int argc,char *argv[]){
  int welcomeSocket, newSocket;
  struct sockaddr_in serverAddr;
  struct sockaddr_storage serverStorage;
  socklen_t addr_size;
int p,k;
  /*---- Create the socket. The three arguments are: ----*/
  /* 1) Internet domain 2) Stream socket 3) Default protocol (TCP in this case) */
  welcomeSocket = socket(PF_INET, SOCK_STREAM, 0);
  
  /*---- Configure settings of the server address struct ----*/
  /* Address family = Internet */
  serverAddr.sin_family = AF_INET;
  /* Set port number, using htons function to use proper byte order */
  serverAddr.sin_port = htons(atoi(argv[2]));
  /* Set IP address to localhost */
  serverAddr.sin_addr.s_addr = inet_addr(argv[1]);
  /* Set all bits of the padding field to 0 */
  memset(serverAddr.sin_zero, '\0', sizeof (serverAddr.sin_zero));  

  /*---- Bind the address struct to the socket ----*/
  bind(welcomeSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));
 // int yes=1;
 // setsockopt(welcomeSocket,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));

  /*---- Listen on the socket, with 5 max connection requests queued ----*/
  if(listen(welcomeSocket,5)==0)
    printf("Listening\n");
  else
    printf("Error\n");

  /*---- Accept call creates a new socket for the incoming connection ----*/

while(1)
{

  addr_size = sizeof (serverStorage);
  newSocket = accept(welcomeSocket, (struct sockaddr *) &serverStorage, &addr_size);

  /*---- Send message to the socket of the incoming connection ----*/
pid_t pid;
pid=fork();
if(pid<0)
printf("error in fork ...\n");
else if(pid==0)
{
close(welcomeSocket);
func(newSocket);
//printf("%d\n",new);
close(newSocket);
exit(0);
}
else 
{
close(newSocket);
}
}
return 0;
}



void func(int newSocket)
{int k,i;
int newsock;
char buffer[1024];
struct hostent *t;
char mssg[1024];
int port=80;
char ip[100];
char page[100];
char s1[1024];
char s2[1024];
char s3[1024];
char* temp=NULL;
int check=0;
memset(mssg,'\0',1024);
int y=recv(newSocket,mssg,1024,0);
int l=strlen(mssg);
if(mssg[l-1]=='\n')
mssg[l-1]='\0';
if(y<0)
{
printf("Request recieving failed ...\n");
return ;
}
int flag=0;

sscanf(mssg,"%s %s %s",s1,s2,s3);


if((strncmp(s1,"GET",3)==0)&&(strncmp(s2,"http://",7)==0)&&(strncmp(s3,"HTTP/1.1",8)==0))
{
strcpy(s1,s2);
for(i=7;i<strlen(s2);i++)
{
if(s2[i]==':')
{
flag=1;
break;
}
}

if(flag==0)
{
// port is not specified.
temp=strtok(s2,"//");
temp=strtok(NULL,"/");
sprintf(ip,"%s",temp);
port=80;
}
else
{
// port is specified.
temp=strtok(s2,"//");
temp=strtok(NULL,":");
int j;
for(j=1;j<strlen(temp);j++)
ip[j-1]=temp[j];
ip[j-1]='\0';
// sprintf(ip,"%s",temp);
temp=strtok(NULL,"/");
port=atoi(temp);
}
printf("Host :%s",ip);
strcat(s1,"^]");
temp=strtok(s1,"//");
temp=strtok(NULL,"/");
if(temp!=NULL)
temp=strtok(NULL,"^]");
printf("\npath = %s\nPort = %d\n",temp,port);

memset(buffer,'\0',1024);

if(temp!=NULL)
{
sprintf(buffer,"GET /%s %s\r\nHost: %s\r\nConnection: close\r\n\r\n",temp,s3,ip);
}
else
{
sprintf(buffer,"GET / %s\r\nHost: %s\r\nConnection: close\r\n\r\n",s3,ip);
}
}

else
{
char errormsg[1024]="400 : BAD REQUEST\nONLY HTTP REQUESTS ALLOWED\n";
send(newSocket,errormsg,1024,0);
return ;
}

/*

--------------------------------------------------------------------------------------------------------------
if(sscanf(mssg, "GET http://%99[^:]:%d %s", ip, &port, page)==3)
{
// printf("%s %d %s",ip,port,page);
}
else if(sscanf(mssg1, "GET http://%s %s", ip,page)==2)
{
// printf("%s %d %s",ip,port,page);
}

// printf("%s %d %s",ip,port,page);

---------------------------------------------------------------------------------------------------------------
*/

newsock=socket(PF_INET,SOCK_STREAM,0);
struct sockaddr_in serv;
t=gethostbyname(ip);
serv.sin_family=AF_INET;
serv.sin_port=htons(port);
memset(serv.sin_zero,0,sizeof(serv.sin_zero));
bcopy((char*)t->h_addr,(char*)&serv.sin_addr.s_addr,t->h_length);


/*

--------------------------------------------------------------------------------------------------------------

// printf("%s",(char*)serv.sin_addr.s_addr);
// printf("%s",t->h_name);
char ip1[100];
strcpy(ip1,inet_ntoa( *( struct in_addr*)( t-> h_addr_list[0])));

while ( t -> h_addr_list[i] != NULL) {
         // printf( "%s ", inet_ntoa( *( struct in_addr*)( t-> h_addr_list[i])));
         
          i++;
       }
// printf("%s",ip1);

serv.sin_addr.s_addr=inet_addr(ip1);

-----------------------------------------------------------------------------------------------------------------
*/


k=connect(newsock,(struct sockaddr*)&serv,sizeof(serv));
// sprintf(buffer,"\nConnected to %s  IP - %s\n",t2,inet_ntoa(serv.sin_addr));
if(k<0)
{
error("Error in connecting to remote server");
return;
}
char mssg1[1024];
sprintf(mssg1,"\nConnected to %s  IP - %s\n\n",ip,inet_ntoa(serv.sin_addr));
printf("%s",mssg1);
// bzero((char*)buffer,sizeof(buffer));

// else
// sprintf(buffer,"GET / %s\r\nHost: %s\r\nConnection: close\r\n\r\n",t3,t2);
 
int n;

n=send(newsock,buffer,strlen(buffer),0);

if(n<0)
error("Error writing to socket");
else
{
do
{
bzero((char*)buffer,1000);
n=recv(newsock,buffer,1000,0);
if(!(n<=0))
send(newSocket,buffer,n,0);
}while(n>0);

}


}


