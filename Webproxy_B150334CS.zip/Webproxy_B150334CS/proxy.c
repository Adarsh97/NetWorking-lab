/****************** SERVER CODE ****************/

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include<unistd.h>
#include<math.h>
#include<stdlib.h>
#include<sys/types.h>
#include<netdb.h>
// #include<error.h>


void func(int newSocket);

int main(int argc,char *argv[]){
  int welcomeSocket, newSocket;
  struct sockaddr_in serverAddr;
  struct sockaddr_storage serverStorage;
  socklen_t addr_size;
int p,k;
  /*---- Create the socket. The three arguments are: ----*/
  /* 1) Internet domain 2) Stream socket 3) Default protocol (TCP in this case) */
  welcomeSocket = socket(PF_INET, SOCK_STREAM, 0);
  
  /*---- Configure settings of the server address struct ----*/
  /* Address family = Internet */
  serverAddr.sin_family = AF_INET;
  /* Set port number, using htons function to use proper byte order */
  serverAddr.sin_port = htons(atoi(argv[2]));
  /* Set IP address to localhost */
  serverAddr.sin_addr.s_addr = inet_addr(argv[1]);
  /* Set all bits of the padding field to 0 */
  memset(serverAddr.sin_zero, '\0', sizeof (serverAddr.sin_zero));  

  /*---- Bind the address struct to the socket ----*/
  bind(welcomeSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));
 // int yes=1;
 // setsockopt(welcomeSocket,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));

  /*---- Listen on the socket, with 5 max connection requests queued ----*/
  if(listen(welcomeSocket,5)==0)
    printf("Listening\n");
  else
    printf("Error\n");

  /*---- Accept call creates a new socket for the incoming connection ----*/

while(1)
{

  addr_size = sizeof (serverStorage);
  newSocket = accept(welcomeSocket, (struct sockaddr *) &serverStorage, &addr_size);

  /*---- Send message to the socket of the incoming connection ----*/
pid_t pid;
pid=fork();
if(pid<0)
printf("error in fork ...\n");
else if(pid==0)
{
close(welcomeSocket);
func(newSocket);
//printf("%d\n",new);
close(newSocket);
exit(0);
}
else 
{
close(newSocket);
}
}
return 0;
}



void func(int newSocket)
{int k,i;
int newsock;
char buffer[1024];
struct hostent *t;
char mssg[1024];
int port=80;
char ip[100];
char page[100];
int check=0;
int y=recv(newSocket,mssg,1024,0);
int l=strlen(mssg);
if(mssg[l-1]=='\n')
mssg[l-1]='\0';
if(y<0)
{
printf("Request recieving failed ...\n");
return ;
}

char mssg1[1024];
strcpy(mssg1,mssg);
if(sscanf(mssg, "GET http://%99[^:]:%d %s", ip, &port, page)==3)
{
// printf("%s %d %s",ip,port,page);
}
else if(sscanf(mssg1, "GET http://%s %s", ip,page)==2)
{
// printf("%s %d %s",ip,port,page);
}
else
{
char errormsg[1024]="400 : BAD REQUEST\nONLY HTTP REQUESTS ALLOWED";
send(newSocket,errormsg,1024,0);
return ;
}
// printf("%s %d %s",ip,port,page);
newsock=socket(PF_INET,SOCK_STREAM,0);
struct sockaddr_in serv;
t=gethostbyname(ip);
serv.sin_family=AF_INET;
serv.sin_port=htons(port);
memset(serv.sin_zero,0,sizeof(serv.sin_zero));
// printf("%s",(char*)serv.sin_addr.s_addr);
// printf("%s",t->h_name);
char ip1[100];
strcpy(ip1,inet_ntoa( *( struct in_addr*)( t-> h_addr_list[0])));
/*
while ( t -> h_addr_list[i] != NULL) {
         // printf( "%s ", inet_ntoa( *( struct in_addr*)( t-> h_addr_list[i])));
         
          i++;
       }
*/

// printf("%s",ip1);

serv.sin_addr.s_addr=inet_addr(ip1);


k=connect(newsock,(struct sockaddr*)&serv,sizeof(serv ));
// sprintf(buffer,"\nConnected to %s  IP - %s\n",t2,inet_ntoa(serv.sin_addr));
if(k<0)
{
error("Error in connecting to remote server");
}
bzero((char*)buffer,sizeof(buffer));

// else
// sprintf(buffer,"GET / %s\r\nHost: %s\r\nConnection: close\r\n\r\n",t3,t2);
 
int n;
memset(buffer,'\0',1024);
 sprintf(buffer,"GET / %s\r\n\r\n",page);
// printf("%s",buffer);
n=send(newsock,buffer,strlen(buffer),0);

if(n<0)
error("Error writing to socket");
else
{
do
{
bzero((char*)buffer,1000);
n=recv(newsock,buffer,1000,0);
if(!(n<=0))
send(newSocket,buffer,n,0);
}while(n>0);

}


}


